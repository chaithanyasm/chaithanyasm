# music-recommendation-app-python
🎵 Lyrics-Based Music Recommendation System A content-based music recommender built using TF-IDF and cosine similarity on song lyrics. Built with Python and Streamlit for fast, interactive song suggestions.
